#!/usr/bin/env python3

import subprocess

def ask_gpt4(rull, prompt):
    command = f"./gpt4.sh \"{rull}\" \"{prompt}\""
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            return result.stdout.strip(), result.stderr.strip()
        else:
            return None  # Return None if return status is not 0
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        return None

stdout, stderr = ask_gpt4("You are ChatGPT", "callculer 1+2+3")
print("stdout",stdout)
print("stderr",stderr)
