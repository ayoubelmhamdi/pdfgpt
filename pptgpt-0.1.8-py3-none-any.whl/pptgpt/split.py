#!/usr/bin/env python3
from langchain.text_splitter import MarkdownHeaderTextSplitter
from langchain.text_splitter import RecursiveCharacterTextSplitter


def list_tokenized_texts(markdown_document, tokens_llm_input=1500, chunk_overlap=30):
    # max_tokens of gpt3.5 means input_toknes should be less
    # then 1500 tokens = 1500*3.333 chars

    chunk_size = tokens_llm_input * 3.33
    headers_to_split_on = [
        ("#", "Header 1"),
        # ("##", "Header 2"),
    ]

    # MD splits
    markdown_splitter = MarkdownHeaderTextSplitter(
        headers_to_split_on=headers_to_split_on
    )
    md_header_splits = markdown_splitter.split_text(markdown_document)

    # Char-level splits
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )

    # Split
    splits = text_splitter.split_documents(md_header_splits)

    correct_text_tokenized = []
    for chunk in splits:
        text = ""
        if chunk.metadata is not None:
            if "Header 1" in chunk.metadata:
                text = "# \n"
                text += chunk.metadata["Header 1"]
            if "Header 2" in chunk.metadata:
                text += "## \n"
                text += chunk.metadata["Header 2"]
            if chunk.page_content is not None:
                text += "\n"
                text += chunk.page_content
        text += "\n\n"
        correct_text_tokenized.append(text)
        # break

    return correct_text_tokenized


if __name__ == "__main__":
    markdown_document2 = """
    Intro
    History
    Markdown[9] is a lightweight markup language for creating formatted text using a plain-text editor. John Gruber created Markdown in 2004 as a markup language that is appealing to human readers in its source code form.[9]
    Markdown is widely used in blogging, instant messaging, online forums, collaborative software, documentation pages, and readme files.
    ## Rise and divergence
    As Markdown popularity grew rapidly, many Markdown implementations appeared, driven mostly by the need for
    additional features such as tables, footnotes, definition lists,[note 1] and Markdown inside HTML blocks.
    #### Standardization
    From 2012, a group of people, including Jeff Atwood and John MacFarlane, launched what Atwood characterised as a standardisation effort.
    ## Implementations
    Implementations of Markdown are available for over a dozen programming languages.
    """
    print(list_tokenized_texts(markdown_document2))
    # print(markdown_document2)
