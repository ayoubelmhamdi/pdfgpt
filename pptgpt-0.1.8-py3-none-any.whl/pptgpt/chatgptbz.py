#!/usr/bin/env python3

import requests
import json
import sys

url = 'https://chat.gpt.bz/api/openai/v1/chat/completions?conversation_id=1bi606L4LRZ6pZ9CaxCvZ'
headers = {
    'authority': 'chat.gpt.bz',
    'accept': 'text/event-stream',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,fr;q=0.7,ar;q=0.6',
    'authorization': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNjUzOGI1NTdlZTU3Y2IwMDAxZWYyZmQ0Iiwic291cmNlIjoiZ3B0LWRlbW8iLCJleHAiOjE3MDA4MDcyNTV9.cfGS13XOJ-1JChMx1fI_2GO8NDg-FSUycXJNbz_c4ZA',
    'content-type': 'application/json',
    'origin': 'https://chat.gpt.bz',
    'referer': 'https://chat.gpt.bz/',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Linux"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'sec-gpc': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    'x-requested-with': 'XMLHttpRequest'
}

def log(*args):
    print(*args, file=sys.stderr)

def ask_chatgptbz(admin:str, user:str) -> str|None:
    data = {
      "messages": [
        {
          "role": "system",
          "content": admin
        },
        {
          "role": "user",
          "content": user
        },
      ],
      "stream": False,
      "model": "gpt-4"
    }

    response = requests.post(url, headers=headers, data=json.dumps(data))
    if response.status_code == 200:
        try:
            response_data = json.loads(response.text)
            if 'choices' in response_data and len(response_data['choices']) > 0:
                choice = response_data['choices'][0]
                if 'message' in choice and 'content' in choice['message']:
                    content = choice['message']['content']
                    if content:
                        return content
                else:
                    log("Expected keys not found in the response.")
            else:
                log("Expected keys not found in the response.")
        
        except json.JSONDecodeError:
            log("Failed to parse the response. Invalid JSON format.")
        
        except Exception as e:
            log(f"An unexpected error occurred: {e}")

    log(f"^^^\n response.text: {response.text}^^^\n")
    return None

if __name__ == "__main__":
    x = ask("You are chatgpt","calculate 1+11+22")
    if x:
        print(x)
