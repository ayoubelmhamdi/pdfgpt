#!/usr/bin/env python3

import tiktoken


def all_tokens(admin, user):
    encoding = tiktoken.encoding_for_model("gpt-4")
    return len(encoding.encode(admin + user))


if __name__ == "__main__":
    # l = all_tokens("you are chatgpt", "calcluer 1+2")
    # print(l)
    import sys
    with open(sys.argv[1], "r") as f:
        s = f.read()
        num = all_tokens(s, "")
        price_gpt3_tubo_4k_token  = 200 * (0.0015 + 0.002) / 1000.0
        price_gpt3_tubo_16k_token = 200 * (0.0030 + 0.004) / 1000.0
        price_gpt4_tubo_8k_token  = 200 * (0.03 + 0.06) / 1000.0
        price_gpt4_tubo_32k_token  = 200 * (0.06 + 0.12) / 1000.0

        t_gpt34 = num * price_gpt3_tubo_4k_token
        t_gpt316 = num * price_gpt3_tubo_16k_token
        t_gpt4 = num * price_gpt4_tubo_8k_token
        t_gpt432 = num * price_gpt4_tubo_32k_token

        s_gpt34 = str(t_gpt34)[:2]
        s_gpt316 =  str(t_gpt316)[:2]
        s_gpt4 = str(t_gpt4)[:2]
        s_gpt432 = str(t_gpt432)[:2]

        print(f"tokens:   {num} token")
        print("------------------\n")
        print(f"gpt3-4k:  {s_gpt34} real")
        # print(f"gpt3-16k: {s_gpt316} real")
        print(f"gpt4-8k:  {s_gpt4} real")
        # print(f"gpt4-32k: {s_gpt432} real")
