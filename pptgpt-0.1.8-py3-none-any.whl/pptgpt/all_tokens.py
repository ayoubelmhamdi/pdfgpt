#!/usr/bin/env python3

import tiktoken

def all_tokens(admin, user):
    encoding = tiktoken.encoding_for_model("gpt-4")
    return len(encoding.encode(admin+user))

if __name__ == "__main__":
    l = all_tokens("you are chatgpt", "calcluer 1+2")
    print(l)
