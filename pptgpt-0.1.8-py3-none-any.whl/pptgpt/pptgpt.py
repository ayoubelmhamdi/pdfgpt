#!/usr/bin/env python3
# import argparse
import asyncio
import json
import logging
import os
import re
import sys
import time

import aiohttp
import openai
import requests
from dotenv import load_dotenv
from tenacity import after_log
from tenacity import retry
from tenacity import stop_after_attempt
from tenacity import wait_random_exponential

from .varibales import Variables

# from tenacity import stop_never

load_dotenv()


OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
APP_ID = os.environ.get("APP_ID")
APP_KEY = os.environ.get("APP_KEY")

openai.api_key = OPENAI_API_KEY


URL = "https://api.openai.com/v1/chat/completions"
HEADERS = {
    "authorization": f"Bearer {OPENAI_API_KEY}",
    "content-type": "application/json",
}

URL_MATHPIX = "https://api.mathpix.com/v3/pdf"

HEADERS_MATHPIX = {
    "app_id": APP_ID,
    "app_key": APP_KEY,
    # "Content-type": "application/json", # no put it with this api
}


DATA = {
    "options_json": '{ "conversion_formats": {"docx": "false", "tex.zip": "false"},"math_inline_delimiters": ["$$", "$$"], "rm_spaces": true}',
}


# TODO use api to change langue
EN = False
if EN:
    OCR = Variables.OCR_EN
    OCR_PPT = Variables.OCR_PPT_EN
    PARAPHRASING = Variables.PARAPHRASING_EN
    PARAPHRASING_PREFIX = Variables.PARAPHRASING_PREFIX_EN
    FUNCTION_EXTRAIRE_STRUCTURE_TEXTE = Variables.FUNCTION_EXTRAIRE_STRUCTURE_TEXTE_EN
else:
    OCR = Variables.OCR_FR
    OCR_PPT = Variables.OCR_PPT_FR
    PARAPHRASING = Variables.PARAPHRASING_FR
    PARAPHRASING_PREFIX = Variables.PARAPHRASING_PREFIX_FR
    FUNCTION_EXTRAIRE_STRUCTURE_TEXTE = Variables.FUNCTION_EXTRAIRE_STRUCTURE_TEXTE_FR

# ----------------------------------


def mathpix_post(pdf_binary):  # sourcery skip: remove-unnecessary-else
    response = None
    try:
        # with open(pdf_file, "rb") as f:
        #     response = requests.post(
        #         URL_MATHPIX,
        #         headers=HEADERS_MATHPIX,  # no a probleme at now
        #         data=DATA,
        #         files={"file": f},
        #     )
        response = requests.post(
            URL_MATHPIX,
            headers=HEADERS_MATHPIX,  # no a probleme at now
            data=DATA,
            files={"file": pdf_binary},
        )
    # Handle the exception if the file is not found or cannot be opened
    except FileNotFoundError as e:
        print(
            f"Error: pdf_file not found or cannot be opened\n ERORE: {e}",
            file=sys.stderr,
        )
        return None
    # Handle the exception if the request fails or returns an error
    except requests.RequestException as e:
        print(f"Error: {e}", file=sys.stderr)
        return None

    if response is not None:
        if response.status_code != 200:
            print("Error submitting PDF for conversion", file=sys.stderr)
            return None

        # Get the PDF ID from the response
        try:
            response_json = response.json()
            if "pdf_id" in response_json:
                return response_json["pdf_id"]
            else:
                print("Error: pdf_id not found in the response", file=sys.stderr)
                return None
        except json.JSONDecodeError as e:
            print(
                f"Error: could not parse the response text as JSON\n ERORE: {e}",
                file=sys.stderr,
            )
            return None
        except KeyError as e:
            print(
                f"Error: could not access the pdf_id key\n ERORE: {e}", file=sys.stderr
            )
            return None


def mathpix_response(url):
    response = None
    try:
        response = requests.get(url, headers=HEADERS_MATHPIX)
    except requests.RequestException as e:
        print(f"Error: {e}", file=sys.stderr)
    except json.JSONDecodeError as e:
        print(f"Error: {e}", file=sys.stderr)

    if response is not None:
        if response.status_code == 200:
            return response
        else:
            print(f"resonse of status of spliting ERROR {response}", file=sys.stderr)
    return None


def pdf_to_garbage_json(pdf_id):
    response = mathpix_response(f"{URL_MATHPIX}/{pdf_id}.lines.json")
    if response is not None:
        response_json = json.loads(response.text)
        if "pages" in response_json:
            return response_json["pages"]
        else:
            print("Error: pages not found in the response", file=sys.stderr)
            return None
    return None


def status_of_splitting(pdf_id):
    while True:
        response_json = mathpix_response(f"{URL_MATHPIX}/{pdf_id}")
        if response_json is not None:
            response_json = response_json.json()
            if "error" in response_json:
                message = response_json["error"]
                print(f"this is an error occure:{message}", file=sys.stderr)
                break
            elif "status" in response_json:
                status = response_json["status"]
                if status == "completed":
                    print("Status is 'complete'", file=sys.stderr)
                    break
                elif status == "error":
                    print(response_json, file=sys.stderr)
                    return None
                elif status == "split":
                    # Get the percent_done, input_file, and num_pages from the result
                    percent_done = response_json["percent_done"]
                    input_file = response_json["input_file"]
                    num_pages = response_json["num_pages"]
                    # Print a message with the progress information
                    print(
                        f"{input_file}: {num_pages} pages  {percent_done:.2f}%",
                        file=sys.stderr,
                    )
                    # Wait for five seconds
                    time.sleep(5)
                else:
                    # Print a message for an invalid status and wait for five seconds
                    print("Invalid status, sleep 5s", file=sys.stderr)
                    time.sleep(5)
        time.sleep(1)
    print("PDF splitting is completed in cloud!", file=sys.stderr)


def status_of_spliting1(pdf_id):
    while True:
        response = None
        try:
            response = requests.get(f"{URL_MATHPIX}/{pdf_id}", headers=HEADERS_MATHPIX)
        except requests.RequestException as e:
            print(f"Error: {e}", file=sys.stderr)
            time.sleep(2)
        except json.JSONDecodeError as e:
            print(f"Error: {e}", file=sys.stderr)
            time.sleep(2)

        if response is not None:
            if response.status_code == 200:
                response_json = response.json()
                if "error" in response_json:
                    message = response_json["error"]
                    print(f"this is an error occure:{message}", file=sys.stderr)
                    break
                elif "status" in response_json:
                    status = response_json["status"]
                    if status == "completed":
                        print("Status is 'complete'", file=sys.stderr)
                        break
                    elif status == "error":
                        print(response_json, file=sys.stderr)
                        return None
                    elif status == "split":
                        # Get the percent_done, input_file, and num_pages from the result
                        percent_done = response_json["percent_done"]
                        input_file = response_json["input_file"]
                        num_pages = response_json["num_pages"]
                        # Print a message with the progress information
                        print(
                            f"{input_file}: {num_pages} pages  {percent_done:.2f}%",
                            file=sys.stderr,
                        )
                        # Wait for five seconds
                        time.sleep(5)
                    else:
                        # Print a message for an invalid status and wait for five seconds
                        print("Invalid status, sleep 5s", file=sys.stderr)
                        time.sleep(5)
            else:
                print(
                    f"resonse of status of spliting ERROR {response}", file=sys.stderr
                )
        # wait for splitting
        time.sleep(1)
    print("PDF splitting is completed in cloud!", file=sys.stderr)


async def stop_request(session, timeout=120, **kwargs):
    """
    Cette fonction fait une requête HTTP asynchrone à l'API d'OpenAI et retourne la réponse JSON.
    Elle gère l'exception asyncio.TimeoutError si la requête dépasse le délai spécifié.
    Elle prend en paramètres :
    - session : une session aiohttp.ClientSession
    - prompt : une chaîne de caractères contenant le prompt à envoyer à l'API
    - timeout : un nombre réel contenant le délai en secondes de la requête
    """

    DATA = {}
    if "messages" in kwargs:
        DATA["messages"] = kwargs["messages"]
    if "functions" in kwargs:
        DATA["functions"] = kwargs["functions"]
    if "max_tokens" in kwargs:
        DATA["max_tokens"] = kwargs["max_tokens"]
    if "model" not in kwargs:
        DATA["model"] = "gpt-3.5-turbo"
    try:
        async with session.post(
            URL, headers=HEADERS, json=DATA, timeout=timeout
        ) as response:
            # on utilise l'argument nommé pour le délai
            return await response.json()
    except asyncio.TimeoutError:
        # on utilise logging au lieu de print
        logging.error("La requête a dépassé le délai")
        sys.exit()
    except aiohttp.ClientError as e:
        # on gère l'exception aiohttp.ClientError
        logging.error(f"Une erreur est survenue lors de la requête : {e}")
        sys.exit()


async def ask_openai(**kwargs):
    async with aiohttp.ClientSession() as session:
        response = await stop_request(session, timeout=20, **kwargs)
        try:
            return response
        except json.JSONDecodeError as e:
            logging.error(
                f"Une erreur est survenue lors du traitement de la réponse : {e}"
            )


# def ask2(**kwargs):
#     # return completion_with_backoff(**kwargs)
#     return openai.ChatCompletion.create(**kwargs)


# async def ask():
#     print("start", file=sys.stderr)
#     prompt = "Bonjour, c'est OpenAI."
#     messages = [{"role": "user", "content": prompt}]
#     response = await ask_openai(messages=messages)
#     print(response, file=sys.stderr)


def get_pages_as_messages(pages=None, content=None, prefix=None):
    list_as_messages = []

    if pages is not None:
        for page in pages:
            if content is not None:
                if prefix is not None:
                    content = f"{prefix}'''\n{content}\n'''"
                messages = [
                    {
                        "role": "system",
                        "content": content,
                    },
                    {
                        "role": "user",
                        "content": page,
                    },
                ]
            else:
                messages = [
                    {
                        "role": "user",
                        "content": page,
                    },
                ]
            list_as_messages.append(messages)
    return list_as_messages


def get_garbage_texts_as_messages(pages):
    return get_pages_as_messages(pages, OCR)


def get_correct_texts_as_messages(pages):
    return get_pages_as_messages(pages)


def get_paraphrases_as_messages(pages):
    return get_pages_as_messages(pages, PARAPHRASING, PARAPHRASING_PREFIX)


## read json from local
def pdf_to_garbage_json2(response):
    # pdf => pdf_id
    # pdf_id => garbage_json_response
    # garbage_json_response => garbage_json
    return json.loads(response.text)["pages"]


def pdf_id_to_garbage_json(pdf_id):
    json_file = f"/tmp/{pdf_id}.lines.json"
    # json_file=f"/tmp/k.json"
    print(json_file, file=sys.stderr)
    with open(json_file, "r") as f:
        pages = json.load(f)["pages"]
    return pages


def garbage_json_to_garbage_text(lines=None, image=None):
    text = ""
    if lines is not None:
        font_size = None  # Initialize font_size as None
        for line in lines:
            # text_new = line['text'].replace('\\', '\\\\') + "\n" # No need to escape backslashes
            text_new = line["text"] + "\n"  # No need to escape backslashes
            if font_size is None:
                font_size = line["font_size"]
                text_new = f"<font size='{font_size}'>\n{text_new}"  # Use single quotes for attribute
            elif line["font_size"] != font_size:
                text += "</font>\n"
                font_size = line["font_size"]
                text_new = f"<font size='{font_size}'>\n{text_new}"
            text += text_new
        text += "</font>"
    if image is not None:
        text += f"\n<img>{image}.jpg</img>"
    return text


def correct_json_to_corrorect_ppt_json(data):
    pattern = r"^[-\d.()]+\s*"

    for item in data:
        if isinstance(item["paragraphs"], str):
            item["paragraphs"] = item["paragraphs"].split("\n")
        for i, paragraph in enumerate(item["paragraphs"]):
            item["paragraphs"][i] = re.sub(pattern, "", paragraph)

    return data


def res_to_text(response):
    try:
        if message := response["choices"][0]["message"]["content"]:
            return message  # test
    except Exception as e:
        print(f"An error occurred: {e}", file=sys.stderr)

    return ""


def res_correcte_text_to_text(response):
    return res_to_text(response)


def res_paraphrase_text_to_text(response):
    return res_to_text(response)


def res_correcte_json_to_text(response):
    try:
        if message := response["choices"][0]["message"]:
            json_message = json.loads(str(message))
            json_str = re.sub(
                r'(\\)(?![\\"])', r"\\\\", json_message["function_call"]["arguments"]
            )
            return json.loads(json_str.replace("\\\\n", "\\n"))
    except Exception as e:
        print(f"An error occurred: {e}", file=sys.stderr)

    return json.loads("{}")


logger = logging.getLogger("mylogger")  # create a logger named 'mylogger'
logger.setLevel(logging.DEBUG)  # set the logger level to DEBUG


@retry(
    wait=wait_random_exponential(min=1, max=60),
    stop=stop_after_attempt(20),
    after=after_log(logger, logging.DEBUG),
)
def completion_with_backoff(**kwargs):
    return openai.ChatCompletion.create(**kwargs)


def ask_for_text(messages=None, model="gpt-3.5-turbo"):
    # we should load the api_key here
    openai.api_key = os.environ.get("OPENAI_API_KEY")
    return completion_with_backoff(
        messages=messages,
        model=model,
        # max_tokens=100,
        temperature=0.1,
    )


def ask_for_text2(messages=None, model="gpt-3.5-turbo"):
    # we should init api_key here
    openai.api_key = os.environ.get("OPENAI_API_KEY")
    #
    # print(
    #     "OPENAI_API_KEY in PPTgpt",
    #     os.getenv("OPENAI_API_KEY"),
    #     file=sys.stderr,
    # )
    # sys.exit(1)

    return openai.ChatCompletion.create(
        messages=messages,
        model=model,
        # max_tokens=100,
        temperature=0.1,
    )


def ask_for_correcte_text(messages):
    return ask_for_text(messages=messages)


def ask_for_paraphrase_text(messages):
    return ask_for_text(
        messages=messages,
        model="gpt-3.5-turbo-16k",
    )


def ask_for_correcte_json(messages):
    # def ask_using_functions(messages):
    functions = []
    functions.append(FUNCTION_EXTRAIRE_STRUCTURE_TEXTE)

    return completion_with_backoff(
        messages=messages,
        model="gpt-3.5-turbo-0613",
        # max_tokens=100,
        temperature=0.1,
        functions=functions,
    )


# def pdf_to_json(pdf_binary):
def list_garbage_json(pdf_binary):
    # pdf_id = mathpix_post("/tmp/file.pdf")
    pdf_id = mathpix_post(pdf_binary)

    if pdf_id is None:
        return None
    print(pdf_id, file=sys.stderr)
    status_of_splitting(pdf_id)
    # status_of_splitting(pdf_id)
    garbage_json = pdf_to_garbage_json(pdf_id)

    if garbage_json is None:
        print("E005: Mathpix can return garbage jsons", file=sys.stderr)
        sys.exit(1)

    return garbage_json


def list_garbage_texts(garbage_json):
    # pdf_id = "2023_07_22_c9798da4fbb1705fb316g"
    # garbage_json = pdf_id_to_garbage_json(pdf_id)
    garbage_texts = []

    for page in garbage_json:  # loop in json
        # print(page, file=sys.stderr)
        image_id = None
        lines = None
        lenght = 0
        if "image_id" in page:
            image_id = page["image_id"]
            lenght += len(image_id)
        if "lines" in page:
            lines = page["lines"]
            lenght += len(lines)
        print(f"len of garbage json page is: {lenght}", file=sys.stderr)
        garbage_text = garbage_json_to_garbage_text(lines, image_id)
        garbage_texts.append(garbage_text)

    if len(garbage_texts) == 0:
        print(
            "E005:  failed in garbage_json_to_garbage_text(lines, image_id)",
            file=sys.stderr,
        )
        sys.exit(1)
    return garbage_texts


def list_correct_texts(garbage_texts):
    garbage_texts_as_messages = get_garbage_texts_as_messages(garbage_texts)
    correct_texts = []

    for page in garbage_texts_as_messages:
        # print(page, file=sys.stderr)
        res_correcte_text = ask_for_correcte_text(page)
        correct_text = res_correcte_text_to_text(res_correcte_text)
        correct_texts.append(correct_text)

    if len(correct_texts) == 0:
        print("E005:  OPENAI can not return correct texts", file=sys.stderr)
        sys.exit(1)

    return correct_texts


def list_correct_ppt_jsons(correct_texts):
    correct_texts_as_messages = get_correct_texts_as_messages(correct_texts)
    correct_jsons = []

    for page in correct_texts_as_messages:
        # print(page, file=sys.stderr)
        res_correcte_json = ask_for_correcte_json(page)
        # break
        correct_json = res_correcte_json_to_text(res_correcte_json)
        correct_jsons.append(correct_json)

    if len(correct_jsons) == 0:
        print("E005:  OPENAI can not return correct jsons", file=sys.stderr)
        sys.exit(1)

    correct_ppt_jsons = correct_json_to_corrorect_ppt_json(correct_jsons)
    return correct_ppt_jsons


def list_of_splits_to_paraphrase(correct_text_tokenized):
    paraphrases_as_messages = get_paraphrases_as_messages(correct_text_tokenized)
    paraphrases = []

    for page in paraphrases_as_messages:
        res_paraphrase_text = ask_for_paraphrase_text(page)
        paraphrase_text = res_paraphrase_text_to_text(res_paraphrase_text)
        paraphrases.append(paraphrase_text)
        # break

    if len(paraphrases) == 0:
        print("E005:  OPENAI can not return paraphrasing", file=sys.stderr)
        sys.exit(1)

    return paraphrases


def write_correct_ppt_jsons(correct_ppt_jsons):
    with open("/tmp/ppt8.json", "w") as f:
        json_str = json.dumps(correct_ppt_jsons)
        f.write(json_str)


async def main():
    print("hello", file=sys.stderr)
    # pdf_binary = open("file.pdf", "rb").read()
    # pdf_to_json(pdf_binary)


if __name__ == "__main__":
    asyncio.run(main())
    print("fin", file=sys.stderr)
