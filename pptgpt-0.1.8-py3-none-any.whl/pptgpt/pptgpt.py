#!/usr/bin/env python3
import logging
import os
import shlex
import subprocess
import sys

import openai
from tenacity import after_log
from tenacity import retry
from tenacity import stop_after_attempt
from tenacity import wait_random_exponential

from .split import list_tokenized_texts
from .varibales import PROMPT

# from typing import Optional


def ask_gpt4(admin=None, user=None):
    script_directory = os.path.dirname(os.path.abspath(__file__))
    command = f"{script_directory}/gpt4.sh {admin} {user}"
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        return result.returncode, result.stdout.strip(), result.stderr.strip()
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        return None, None, None


class CreateParaphrasing:
    def __init__(self, lang="en", input_texts=None, Tasks=None, Provider=None):
        # assert lang == "fr", "lang is not equal to 'fr'"
        self.llm_option = {
            "admin": {
                "correct_ocr": PROMPT["correct_ocr"][lang]["admin"],
                "ppt": PROMPT["ppt"][lang]["admin"],
                "paraphrasing": PROMPT["paraphrasing"][lang]["admin"],
                "child": PROMPT["child"][lang]["admin"],
            },
            "prefix": {
                "correct_ocr": PROMPT["correct_ocr"][lang]["prefix"],
                "ppt": PROMPT["ppt"][lang]["prefix"],
                "paraphrasing": PROMPT["paraphrasing"][lang]["prefix"],
                "child": PROMPT["child"][lang]["prefix"],
            },
            "fucntion": {
                "ppt": PROMPT["function"]["ppt"][lang],
            },
            "max_tokens": {
                "correct_ocr": PROMPT["correct_ocr"][lang]["max_tokens"],
                "ppt": PROMPT["ppt"][lang]["max_tokens"],
                "paraphrasing": PROMPT["paraphrasing"][lang]["max_tokens"],
                "child": PROMPT["child"][lang]["max_tokens"],
            },
            "model": {
                "correct_ocr": PROMPT["correct_ocr"][lang]["model"],
                "ppt": PROMPT["ppt"][lang]["model"],
                "paraphrasing": PROMPT["paraphrasing"][lang]["model"],
                "child": PROMPT["child"][lang]["model"],
            },
        }

        if input_texts is not None:
            self.output_texts = input_texts
        else:
            raise ValueError("You chould provied garbage text from mathpix/ocr...")

        if Tasks is not None:
            self.Tasks = Tasks
        else:
            raise ValueError("You should provied a task for llm")

        if Provider is not None:
            self.Provider = Provider
        else:
            self.Provider = ""

        self.correct_texts = []
        self.correct_text_tokenized = []
        self.paraphrases = []
        self.child_texts = []

        self.res = None
        self.res_message = []
        self.list_list_as_messages = []

    # -------------------------------------------------

    logger = logging.getLogger("mylogger")  # create a logger named 'mylogger'
    logger.setLevel(logging.DEBUG)  # set the logger level to DEBUG

    @retry(
        wait=wait_random_exponential(min=1, max=60),
        stop=stop_after_attempt(20),
        after=after_log(logger, logging.DEBUG),
    )
    def completion_with_backoff(self, **kwargs):
        return openai.ChatCompletion.create(**kwargs)

    # -------------------------------------------------

    def ask_for_text(self, messages=None, model="gpt-3.5-turbo"):
        # we should load the api_key here
        openai.api_key = os.environ.get("OPENAI_API_KEY")
        return self.completion_with_backoff(
            messages=messages,
            model=model,
            # max_tokens=10,
            temperature=0.1,
        )

    def ask_for_text2(self, messages=None, model="gpt-3.5-turbo"):
        # Assert load openai api_key here for external
        # module that not show internal variable
        openai.api_key = os.environ.get("OPENAI_API_KEY")

        return openai.ChatCompletion.create(
            messages=messages,
            model=model,
            # max_tokens=10,
            temperature=0.1,
        )

    # -------------------------------------------------

    def get_llm(self, task, messages):
        # print("in res", file=sys.stderr)
        model = self.llm_option["model"][task]
        self.res = self.ask_for_text(messages, model)

        if self.res is not None:
            if "choices" in self.res:
                try:
                    message = self.res["choices"][0]["message"]["content"]
                    if message:
                        self.output_texts.append(message)
                    # else:
                    # TODO what if LLM can not gives answer
                except KeyError as e:
                    print(f"Key {e} not found in the \n{self.res}", file=sys.stderr)
                except TypeError as e:
                    print(f"Invalid type in the response: {e}", file=sys.stderr)

        else:
            raise ValueError("self.res is None")
        return self

    # -------------------------------------------------
    def get_items_for_messages(self, page=None, task=None):
        admin, prefix = "", ""
        try:
            admin = self.llm_option["admin"][task]
        except KeyError as e:
            print(f"Key {e} not found in the \n{e}", file=sys.stderr)
        except TypeError as e:
            print(f"Invalid type in the get_messages(): {e}", file=sys.stderr)
        if admin == "":
            raise ValueError("admin is empty")

        try:
            prefix = self.llm_option["prefix"][task]
        except KeyError as e:
            print(f"Key {e} not found in the \n{e}", file=sys.stderr)
        except TypeError as e:
            print(f"Invalid type in the get_messages(): {e}", file=sys.stderr)
        if prefix == "":
            raise ValueError("prefix is empty")

        # page = page.replace("\n", r"\\n")
        # admin = admin.replace("\n", r"\\n")
        user = f"{prefix}\n''\n{page}\n''"
        user = user.replace("\n", r"\\n")

        user = shlex.quote(user)
        admin = shlex.quote(admin)
        return admin, user

    def get_pages_as_messages_self(self, pages=None, task=None):
        admin, prefix = "", ""
        try:
            admin = self.llm_option["admin"][task]
        except KeyError as e:
            print(f"Key {e} not found in the \n{e}", file=sys.stderr)
        except TypeError as e:
            print(f"Invalid type in the get_messages(): {e}", file=sys.stderr)
        if admin == "":
            raise ValueError("admin is empty")

        try:
            prefix = self.llm_option["prefix"][task]
        except KeyError as e:
            print(f"Key {e} not found in the \n{e}", file=sys.stderr)
        except TypeError as e:
            print(f"Invalid type in the get_messages(): {e}", file=sys.stderr)
        if prefix == "":
            raise ValueError("prefix is empty")

        # print(f"admin:\n{admin}", file=sys.stderr)
        # print(f"prefix:\n{prefix}", file=sys.stderr)
        # sys.exit(0)

        if pages is not None:
            if len(pages) > 0:
                for page in pages:
                    if prefix != "":
                        content = f"{prefix}\n'''\n{page}\n'''"
                    else:
                        content = page
                    if admin != "":
                        messages = [
                            {
                                "role": "system",
                                "content": admin,
                            },
                            {
                                "role": "user",
                                "content": content,
                            },
                        ]
                    else:
                        messages = [
                            {
                                "role": "user",
                                "content": content,
                            },
                        ]
                    self.list_list_as_messages.append(messages)
            else:
                raise ValueError("output_texts Array is Empty")
        else:
            raise ValueError("output_texts Array is None")
        return self

    # -------------------------------------------------

    def tokenized_texts(self, task):
        text = ""
        for item in self.output_texts:
            text += item

        if len(text) == 0:
            raise ValueError("text is empty in tokenized_texts()")

        max_tokens = self.llm_option["max_tokens"][task]
        return list_tokenized_texts(text, tokens_llm_input=max_tokens)

    # -------------------------------------------------

    def list_tasks(self):
        for task in self.Tasks:
            if len(self.output_texts) == 0:
                print(
                    "???????????????????????????????????????????\n"
                    f"list_input_of_Output_texts:{len(self.output_texts)} ",
                    f"item in task {task}\n",
                    "???????????????????????????????????????????\n",
                    file=sys.stderr,
                )
                sys.exit(1)

            self.output_texts = self.tokenized_texts(task)

            if self.Provider == "Aivvm":
                output_texts_Aivvm = self.output_texts
                print(
                    "===========================================\n"
                    f"list_Aivvm:{len(output_texts_Aivvm)} "
                    f"item in task {task}",
                    file=sys.stderr,
                )
                self.output_texts = []
                for i, page in enumerate(output_texts_Aivvm):
                    print(
                        "+++++++++++++++++++++++++++++++++++\n",
                        "page:\n",
                        f"{page}\n",
                        "+++++++++++++++++++++++++++++++++++\n",
                        file=sys.stderr,
                    )
                    # self.get_llm(task, messages)
                    admin, user = self.get_items_for_messages(page=page, task=task)
                    print(
                        "+++++++++++++++++++++++++++++++++++\n",
                        "admin:\n",
                        f"{admin}\n",
                        "+++++++++++++++++++++++++++++++++++\n",
                        file=sys.stderr,
                    )
                    print(
                        "+++++++++++++++++++++++++++++++++++\n",
                        "user:\n",
                        f"{user}\n",
                        "+++++++++++++++++++++++++++++++++++\n",
                        file=sys.stderr,
                    )

                    answer_out = None
                    for _ in range(3):
                        answer_code, answer_out, answer_err= ask_gpt4(admin=admin, user=user)
                        print(
                            "-----------------------------------\n",
                            "Answer_code:\n",
                            f"{answer_code}\n",
                            file=sys.stderr,
                        )
                        print(
                            "-----------------------------------\n",
                            "Answer_out:\n",
                            f"{answer_out}\n",
                            file=sys.stderr,
                        )
                        print(
                            "-----------------------------------\n",
                            "Answer_err:\n",
                            f"{answer_err}\n",
                            file=sys.stderr,
                        )

                        if answer_out is not None:
                            self.output_texts.append(answer_out)
                            print(
                                f"^^^^\nself.output_texts\n{self.output_texts}\n^^^^",
                                file=sys.stderr,
                            )
                            break

                    if answer_out is None:
                        print("^^^^\nanswer_out is steel None\n^^^^", file=sys.stderr)
                        sys.exit(1)

                    print(
                        "+++++++++++++++++++++++++++++++++++\n",
                        f"{i+1}/{len(output_texts_Aivvm)} {task} ✔",
                        file=sys.stderr,
                    )

            else:
                self.list_list_as_messages = []
                self.get_pages_as_messages_self(
                    self.output_texts,
                    task,
                )
                print(
                    "===========================================\n"
                    f"list_as_messages:{len(self.list_list_as_messages)}"
                    f" item in task {task}",
                    file=sys.stderr,
                )
                self.output_texts = []
                for i, messages in enumerate(self.list_list_as_messages):
                    print(
                        "+++++++++++++++++++++++++++++++++++\n",
                        f"{messages}\n",
                        file=sys.stderr,
                    )
                    self.get_llm(task, messages)
                    print(
                        "+++++++++++++++++++++++++++++++++++\n",
                        f"{i+1}/{len(self.list_list_as_messages)} {task} ✔",
                        file=sys.stderr,
                    )

        return self.output_texts


# TODO
#   [ ] : check all todos
#   [x] : remove break
#   [x] : comment max_tokens
#   [x] : use logoff llm
#   [x] : test /tmp/2.pdf
