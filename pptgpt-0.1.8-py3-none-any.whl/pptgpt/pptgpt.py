#!/usr/bin/env python3
import logging
import os
import sys
from typing import Optional

import openai
from tenacity import after_log
from tenacity import retry
from tenacity import stop_after_attempt
from tenacity import wait_random_exponential

from .split import list_tokenized_texts
from .varibales import PROMPT


class CreateParaphrasing:
    def __init__(self, lang: Optional[str] = None, input_texts=None, Tasks=None):
        if lang not in {None, "en", "fr"}:
            raise ValueError('word must be either "en", "fr", or None')
        else:
            self.llm_option = {
                "content": {
                    "correct_ocr": PROMPT["correct_ocr"][lang]["prompt"],
                    "ppt": PROMPT["ppt"][lang]["prompt"],
                    "paraphrasing": PROMPT["paraphrasing"][lang]["prompt"],
                    "child": PROMPT["child"][lang]["prompt"],
                },
                "prefix": {
                    "correct_ocr": PROMPT["correct_ocr"][lang]["prefix"],
                    "ppt": PROMPT["ppt"][lang]["prefix"],
                    "paraphrasing": PROMPT["paraphrasing"][lang]["prefix"],
                    "child": PROMPT["child"][lang]["prefix"],
                },
                "fucntion": {
                    "ppt": PROMPT["function"]["ppt"][lang],
                },
            }

        if input_texts is not None:
            self.output_texts = input_texts
        else:
            raise ValueError("You chould provied garbage text from mathpix/ocr...")

        if Tasks is not None:
            self.Tasks = Tasks
        else:
            raise ValueError("You chould provied the task for llm")
        self.correct_texts = []
        self.correct_text_tokenized = []
        self.paraphrases = []
        self.child_texts = []

        self.res = None
        self.res_message = []

    # -------------------------------------------------

    logger = logging.getLogger("mylogger")  # create a logger named 'mylogger'
    logger.setLevel(logging.DEBUG)  # set the logger level to DEBUG

    @retry(
        wait=wait_random_exponential(min=1, max=60),
        stop=stop_after_attempt(20),
        after=after_log(logger, logging.DEBUG),
    )
    def completion_with_backoff(self, **kwargs):
        return openai.ChatCompletion.create(**kwargs)

    # -------------------------------------------------

    def ask_for_text(self, messages=None, model="gpt-3.5-turbo"):
        # we should load the api_key here
        openai.api_key = os.environ.get("OPENAI_API_KEY")
        return self.completion_with_backoff(
            messages=messages,
            model=model,
            # max_tokens=10,
            temperature=0.1,
        )

    def ask_for_text2(self, messages=None, model="gpt-3.5-turbo"):
        # Assert load openai api_key here for external
        # module that not show internal variable
        openai.api_key = os.environ.get("OPENAI_API_KEY")

        return openai.ChatCompletion.create(
            messages=messages,
            model=model,
            # max_tokens=10,
            temperature=0.1,
        )

    # -------------------------------------------------

    def get_llm_res_self(self, task, message):
        # other model: "gpt-3.5-turbo-0613"
        args_dict = {
            "correct_ocr": {
                "messages": message,
                "model": "gpt-3.5-turbo",
            },
            "paraphrasing": {
                "messages": message,
                "model": "gpt-3.5-turbo-16k",
            },
            "child": {
                "messages": message,
                "model": "gpt-3.5-turbo-16k",
            },
            "ppt": {
                "messages": message,
                "model": "gpt-3.5-turbo-16k-0613",
            },
        }

        # get the arguments for the current task
        args = args_dict.get(task, {})

        self.res = self.ask_for_text(**args)

        return self

    def res_to_text_self(self):
        # print("in res", file=sys.stderr)
        if self.res is not None:
            if "choices" in self.res:
                try:
                    message = self.res["choices"][0]["message"]["content"]
                    if message:
                        self.output_texts.append(message)
                    # else:
                    # TODO what if LLM can not gives answer
                except KeyError as e:
                    print(f"Key {e} not found in the \n{self.res}", file=sys.stderr)
                except TypeError as e:
                    print(f"Invalid type in the response: {e}", file=sys.stderr)

        else:
            raise ValueError("self.res is None")
        return self

    def get_pages_as_messages_self(self, pages=None, content=None, prefix=None):
        if pages is not None:
            if len(pages) > 0:
                for page in pages:
                    if content is not None:
                        if prefix is not None:
                            content = f"{prefix}'''\n{content}\n'''"
                        messages = [
                            {
                                "role": "system",
                                "content": content,
                            },
                            {
                                "role": "user",
                                "content": page,
                            },
                        ]
                    else:
                        messages = [
                            {
                                "role": "user",
                                "content": page,
                            },
                        ]
                    self.list_as_messages.append(messages)
            else:
                raise ValueError("output_texts Array is Empty")
        else:
            raise ValueError("output_texts Array is None")
        return self

    def tokenized_texts(self):
        text = ""
        for item in self.output_texts:
            text += item

        if len(text) == 0:
            raise ValueError("text is empty in tokenized_texts()")
        return list_tokenized_texts(text)

    def list_tasks(self):
        for task in self.Tasks:
            self.output_texts = self.tokenized_texts()
            self.list_as_messages = []
            self.get_pages_as_messages_self(
                self.output_texts,
                self.llm_option["content"][task],
                self.llm_option["prefix"][task],
            )
            print(
                "===========================================\n"
                f"list_as_messages:{len(self.list_as_messages)}"
                f" item in task {task}",
                file=sys.stderr,
            )
            self.output_texts = []
            for i, message in enumerate(self.list_as_messages):
                self.get_llm_res_self(task, message).res_to_text_self()
                print(
                    "_____________________________________\n",
                    # f"{message}\n",
                    f"{i+1}/{len(self.list_as_messages)} {task} ✔",
                    file=sys.stderr,
                )
                # if i + 1 == 2:
                #     break

        return self.output_texts


# TODO
#   [ ] : check all todos
#   [x] : remove break
#   [x] : comment max_tokens
#   [x] : use logoff llm
#   [ ] : test /tmp/2.pdf
