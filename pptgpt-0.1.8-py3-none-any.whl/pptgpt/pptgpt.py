#!/usr/bin/env python3
import logging
import os
import sys
from typing import Optional

import openai
from dotenv import load_dotenv
from tenacity import after_log
from tenacity import retry
from tenacity import stop_after_attempt
from tenacity import wait_random_exponential

from .split import list_correct_text_tokenized
from .varibales import Variables

# import json
# import re
# import argparse
# import asyncio
# import time
# import aiohttp
# import requests
# from tenacity import stop_never

load_dotenv()


# OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
# APP_ID = os.environ.get("APP_ID")
# APP_KEY = os.environ.get("APP_KEY")
#
# openai.api_key = OPENAI_API_KEY
#
#
# URL = "https://api.openai.com/v1/chat/completions"
# HEADERS = {
#     "authorization": f"Bearer {OPENAI_API_KEY}",
#     "content-type": "application/json",
# }
#
# URL_MATHPIX = "https://api.mathpix.com/v3/pdf"
#
# HEADERS_MATHPIX = {
#     "app_id": APP_ID,
#     "app_key": APP_KEY,
#     # "Content-type": "application/json", # no put it with this api
# }
#
#
# DATA = {
#     "options_json": '{ "conversion_formats": {"docx": "false", "tex.zip": "false"},"math_inline_delimiters": ["$$", "$$"], "rm_spaces": true}',
# }


class CreateParaphrasing:
    def __init__(self, lang: Optional[str] = None, garbage_texts=None):
        if lang not in {None, "En", "Fr"}:
            raise ValueError('word must be either "En", "Fr", or None')
        elif lang == "Fr":
            self.OCR = Variables.OCR_FR
            self.OCR_PPT = Variables.OCR_PPT_FR
            self.PARAPHRASING = Variables.PARAPHRASING_FR
            self.PARAPHRASING_PREFIX = Variables.PARAPHRASING_PREFIX_FR
            self.FUNCTION_EXTRAIRE_STRUCTURE_TEXTE = (
                Variables.FUNCTION_EXTRAIRE_STRUCTURE_TEXTE_FR
            )
        else:  # "None or En"
            self.OCR = Variables.OCR_EN
            self.OCR_PPT = Variables.OCR_PPT_EN
            self.PARAPHRASING = Variables.PARAPHRASING_EN
            self.PARAPHRASING_PREFIX = Variables.PARAPHRASING_PREFIX_EN
            self.FUNCTION_EXTRAIRE_STRUCTURE_TEXTE = (
                Variables.FUNCTION_EXTRAIRE_STRUCTURE_TEXTE_EN
            )

        if garbage_texts is not None:
            self.garbage_texts = garbage_texts
        else:
            raise ValueError("You chould provied garbage text from mathpix/ocr")
        self.correct_texts = []
        self.correct_text_tokenized = []
        self.paraphrases = []

    # ----------------------------------

    def get_pages_as_messages(self, pages=None, content=None, prefix=None):
        list_as_messages = []

        if pages is not None:
            for page in pages:
                if content is not None:
                    if prefix is not None:
                        content = f"{prefix}'''\n{content}\n'''"
                    messages = [
                        {
                            "role": "system",
                            "content": content,
                        },
                        {
                            "role": "user",
                            "content": page,
                        },
                    ]
                else:
                    messages = [
                        {
                            "role": "user",
                            "content": page,
                        },
                    ]
                list_as_messages.append(messages)
        return list_as_messages

    def get_garbage_texts_as_messages(self, pages):
        return self.get_pages_as_messages(pages, self.OCR)

    def get_correct_texts_as_messages(self, pages):
        return self.get_pages_as_messages(pages)

    def get_paraphrases_as_messages(self):
        return self.get_pages_as_messages(
            self.correct_text_tokenized, self.PARAPHRASING, self.PARAPHRASING_PREFIX
        )

    def res_to_text(self, response):
        try:
            if message := response["choices"][0]["message"]["content"]:
                return message  # test
        except Exception as e:
            print(f"An error occurred: {e}", file=sys.stderr)

        return ""

    def res_correcte_text_to_text(self, response):
        return self.res_to_text(response)

    def res_paraphrase_text_to_text(self, response):
        return self.res_to_text(response)

    # -------------------------------------------------

    logger = logging.getLogger("mylogger")  # create a logger named 'mylogger'
    logger.setLevel(logging.DEBUG)  # set the logger level to DEBUG

    @retry(
        wait=wait_random_exponential(min=1, max=60),
        stop=stop_after_attempt(20),
        after=after_log(logger, logging.DEBUG),
    )
    def completion_with_backoff(self, **kwargs):
        return openai.ChatCompletion.create(**kwargs)

    # -------------------------------------------------

    def ask_for_text(self, messages=None, model="gpt-3.5-turbo"):
        # we should load the api_key here
        openai.api_key = os.environ.get("OPENAI_API_KEY")
        return self.completion_with_backoff(
            messages=messages,
            model=model,
            # max_tokens=100,
            temperature=0.1,
        )

    def ask_for_text2(self, messages=None, model="gpt-3.5-turbo"):
        # Disable Now
        # we should init api_key here
        openai.api_key = os.environ.get("OPENAI_API_KEY")
        #
        # print(
        #     "OPENAI_API_KEY in PPTgpt",
        #     os.getenv("OPENAI_API_KEY"),
        #     file=sys.stderr,
        # )
        # sys.exit(1)

        return openai.ChatCompletion.create(
            messages=messages,
            model=model,
            # max_tokens=100,
            temperature=0.1,
        )

    def ask_for_correcte_text(self, messages):
        return self.ask_for_text(messages=messages)

    def ask_for_paraphrase_text(self, messages):
        return self.ask_for_text(
            messages=messages,
            model="gpt-3.5-turbo-16k",
        )

    # -------------------------------------------------

    def list_correct_texts(self):
        garbage_texts_as_messages = self.get_garbage_texts_as_messages(
            self.garbage_texts
        )

        for i, page in enumerate(garbage_texts_as_messages):
            # print(page, file=sys.stderr)
            res_correcte_text = self.ask_for_correcte_text(page)
            correct_text = self.res_correcte_text_to_text(res_correcte_text)
            self.correct_texts.append(correct_text)
            print(
                f"ask for page: {i+1}/{len(garbage_texts_as_messages)} ✔",
                file=sys.stderr,
            )

        if len(self.correct_texts) == 0:
            print("E005:  OPENAI can not return correct texts", file=sys.stderr)
            print("Correct_texts x", file=sys.stderr)
            sys.exit(1)
        else:
            print("Correct_texts ✔", file=sys.stderr)

        return self

    # TODO: change to lists
    def correct_text_to_tokenized(self):
        correct_text_str = ""
        for text in self.correct_texts:
            correct_text_str += text
        self.correct_text_tokenized = list_correct_text_tokenized(correct_text_str)
        # TODO: check if empty and raise error
        print("tokenized_texts ✔", file=sys.stderr)
        return self

    def list_of_splits_to_paraphrase(self):
        paraphrases_as_messages = self.get_paraphrases_as_messages()

        for i, page in enumerate(paraphrases_as_messages):
            res_paraphrase_text = self.ask_for_paraphrase_text(page)
            paraphrase_text = self.res_paraphrase_text_to_text(res_paraphrase_text)
            self.paraphrases.append(paraphrase_text)
            print(
                f"ask for paraphrase page: {i+1}/{len(paraphrases_as_messages)} ✔",
                file=sys.stderr,
            )
            # break

        if len(self.paraphrases) == 0:
            print("E008:  OPENAI can not return paraphrasing", file=sys.stderr)
            print("Correct_texts x", file=sys.stderr)
            sys.exit(1)
        else:
            print("paraphrases ✔", file=sys.stderr)

        return self.paraphrases
