#!/usr/bin/env python3
import logging
import math
import os
# import shlex
import sys
import time

import cloudscraper
import openai
from tenacity import after_log
from tenacity import retry
from tenacity import stop_after_attempt
from tenacity import wait_random_exponential

from .split import list_tokenized_texts
from .varibales import PROMPT
from .chatgptbz import ask_chatgptbz
from .all_tokens import all_tokens


# from typing import Optional

scraper = cloudscraper.create_scraper()  # returns a CloudScraper instance


def log(*args):
    print(*args, file=sys.stderr)



def ask_gpt4(user=None, admin=None) -> str:
    json_data = {
        "model": {"id": "gpt-4", "name": "GPT-4"},
        "messages": [{"role": "user", "content": user}],
        "key": "",
        "prompt": admin,
        "temperature": 0.7,
    }

    try:
        response = scraper.post("https://chat.aivvm.com/api/chat", json=json_data)
        return response.text if response.text else ""
    except Exception:
        return ""


class CreateParaphrasing:
    def __init__(self, lang="en", input_texts=None, Tasks=None, Provider=None):
        # assert lang == "fr", "lang is not equal to 'fr'"
        self.llm_option = {
            "admin": {
                "correct_ocr": PROMPT["correct_ocr"][lang]["admin"],
                "ppt": PROMPT["ppt"][lang]["admin"],
                "paraphrasing": PROMPT["paraphrasing"][lang]["admin"],
                "child": PROMPT["child"][lang]["admin"],
            },
            "prefix": {
                "correct_ocr": PROMPT["correct_ocr"][lang]["prefix"],
                "ppt": PROMPT["ppt"][lang]["prefix"],
                "paraphrasing": PROMPT["paraphrasing"][lang]["prefix"],
                "child": PROMPT["child"][lang]["prefix"],
            },
            "fucntion": {
                "ppt": PROMPT["function"]["ppt"][lang],
            },
            "max_tokens": {
                "correct_ocr": PROMPT["correct_ocr"][lang]["max_tokens"],
                "ppt": PROMPT["ppt"][lang]["max_tokens"],
                "paraphrasing": PROMPT["paraphrasing"][lang]["max_tokens"],
                "child": PROMPT["child"][lang]["max_tokens"],
            },
            "model": {
                "correct_ocr": PROMPT["correct_ocr"][lang]["model"],
                "ppt": PROMPT["ppt"][lang]["model"],
                "paraphrasing": PROMPT["paraphrasing"][lang]["model"],
                "child": PROMPT["child"][lang]["model"],
            },
        }

        if input_texts is not None:
            self.output_texts = input_texts
        else:
            raise ValueError("You chould provied garbage text from mathpix/ocr...")

        if Tasks is not None:
            self.Tasks = Tasks
        else:
            raise ValueError("You should provied a task for llm")

        if Provider is not None:
            self.Provider = Provider
        else:
            self.Provider = ""

        self.correct_texts = []
        self.correct_text_tokenized = []
        self.paraphrases = []
        self.child_texts = []

        self.res = None
        self.res_message = []
        self.list_list_as_messages = []

    # -------------------------------------------------

    logger = logging.getLogger("mylogger")  # create a logger named 'mylogger'
    logger.setLevel(logging.DEBUG)  # set the logger level to DEBUG

    @retry(
        wait=wait_random_exponential(min=1, max=60),
        stop=stop_after_attempt(20),
        after=after_log(logger, logging.DEBUG),
    )
    def completion_with_backoff(self, **kwargs):
        return openai.ChatCompletion.create(**kwargs)

    # -------------------------------------------------

    def ask_for_text(self, messages=None, model="gpt-3.5-turbo"):
        # we should load the api_key here
        openai.api_key = os.environ.get("OPENAI_API_KEY")
        return self.completion_with_backoff(
            messages=messages,
            model=model,
            # max_tokens=10,
            temperature=0.1,
        )

    def ask_for_text2(self, messages=None, model="gpt-3.5-turbo"):
        # Assert load openai api_key here for external
        # module that not show internal variable
        openai.api_key = os.environ.get("OPENAI_API_KEY")

        return openai.ChatCompletion.create(
            messages=messages,
            model=model,
            # max_tokens=10,
            temperature=0.1,
        )

    # -------------------------------------------------

    def get_llm(self, task, messages):
        # log("in res")
        model = self.llm_option["model"][task]
        self.res = self.ask_for_text(messages, model)

        if self.res is not None:
            if "choices" in self.res:
                try:
                    message = self.res["choices"][0]["message"]["content"]
                    if message:
                        self.output_texts.append(message)
                    # else:
                    # TODO what if LLM can not gives answer
                except KeyError as e:
                    log(f"Key {e} not found in the \n{self.res}")
                except TypeError as e:
                    log(f"Invalid type in the response: {e}")

        else:
            raise ValueError("self.res is None")
        return self

    # -------------------------------------------------
    def get_items_for_messages(self, page=None, task=None):
        admin, prefix = "", ""
        try:
            admin = self.llm_option["admin"][task]
        except KeyError as e:
            log(f"Key {e} not found in the \n{e}")
        except TypeError as e:
            log(f"Invalid type in the get_messages(): {e}")
        if admin == "":
            raise ValueError("admin is empty")

        try:
            prefix = self.llm_option["prefix"][task]
        except KeyError as e:
            log(f"Key {e} not found in the \n{e}")
        except TypeError as e:
            log(f"Invalid type in the get_messages(): {e}")
        if prefix == "":
            raise ValueError("prefix is empty")

        user = f"{prefix}\n'''\n{page}\n'''"

        user = user.replace("\\", "\\\\").replace('"', '\\"').replace('\n', '\\n')
        admin = admin.replace("\\", "\\\\").replace('"', '\\"').replace('\n', '\\n')

        # user = shlex.quote(user)
        # admin = shlex.quote(admin)
        # admin = admin.replace("\n", r"\\n")
        # user = user.replace("\n", r"\\n")
        return admin, user

    def get_pages_as_messages_self(self, pages=None, task=None):
        admin, prefix = "", ""
        try:
            admin = self.llm_option["admin"][task]
        except KeyError as e:
            log(f"Key {e} not found in the \n{e}")
        except TypeError as e:
            log(f"Invalid type in the get_messages(): {e}")
        if admin == "":
            raise ValueError("admin is empty")

        try:
            prefix = self.llm_option["prefix"][task]
        except KeyError as e:
            log(f"Key {e} not found in the \n{e}")
        except TypeError as e:
            log(f"Invalid type in the get_messages(): {e}")
        if prefix == "":
            raise ValueError("prefix is empty")

        if pages is not None:
            if len(pages) > 0:
                for page in pages:
                    if prefix != "":
                        content = f"{prefix}\n'''\n{page}\n'''"
                    else:
                        content = page
                    if admin != "":
                        messages = [
                            {
                                "role": "system",
                                "content": admin,
                            },
                            {
                                "role": "user",
                                "content": content,
                            },
                        ]
                    else:
                        messages = [
                            {
                                "role": "user",
                                "content": content,
                            },
                        ]
                    self.list_list_as_messages.append(messages)
            else:
                raise ValueError("output_texts Array is Empty")
        else:
            raise ValueError("output_texts Array is None")
        return self

    # -------------------------------------------------

    def tokenized_texts(self, task):
        text = ""
        for item in self.output_texts:
            text += item

        if len(text) == 0:
            raise ValueError("text is empty in tokenized_texts()")

        max_tokens = self.llm_option["max_tokens"][task]
        return list_tokenized_texts(text, tokens_llm_input=max_tokens)

    # -------------------------------------------------

    def list_tasks(self):
        for task in self.Tasks:
            if len(self.output_texts) == 0:
                log(
                    "???????????????????????????????????????????\n"
                    f"list_input_of_Output_texts:{len(self.output_texts)} ",
                    f"item in task {task}\n",
                    "???????????????????????????????????????????\n",
                )
                sys.exit(1)

            self.output_texts = self.tokenized_texts(task)

            if self.Provider == "Chatgptbz":
                output_texts_Chatgptbz = self.output_texts
                log(
                    "===========================================\n"
                    f"list_Chatgptbz:{len(output_texts_Chatgptbz)} "
                    f"item in task {task}",
                )
                self.output_texts = []
                for i, page in enumerate(output_texts_Chatgptbz):
                    # page="aaa"
                    log(
                        "+++++++++++++++++++++++++++++++++++\n",
                        "page:\n",
                        f"{page[:90]}\n",
                    )
                    admin, user = self.get_items_for_messages(page=page, task=task)
                    log(
                        "+++++++++++++++++++++++++++++++++++\n",
                        "admin:\n",
                        f"{admin[:90]}...\n",
                    )
                    log(
                        "+++++++++++++++++++++++++++++++++++\n",
                        "user:\n",
                        f"...{user[90:180]}...\n",
                    )

                    tokens = all_tokens(admin, user)
                    log(f"number of all tokens in this requeste is {tokens} tokens")

                    answer_out = None

                    # answer_out = ask_gpt4(admin=admin, user=user)
                    with open("req.json", 'w') as f:
                        text = '{"messages":[{"role":"system","content":"' + admin + '"},{"role":"user","content":"' + user + '"}],"stream":true,"model":"gpt-4"}'
                        # log(text)
                        f.write(text)
                    # sys.exit(0)
                    answer_out = ask_chatgptbz(admin=admin, user=user)
                    # log(
                    #     "-----------------------------------\n",
                    #     "Answer_out:\n",
                    #     f"{answer_out[:90]}...\n",
                    # )

                    for j in range(10,20):
                        if answer_out and any(
                                s in answer_out.strip().split("\n")[0]
                                for s in [
                                    "<!DOCTYPE html>",
                                    "Error...",
                                    "Error",
                                    ]
                                ):
                                log(f"^^^^\nSTOP: answer_out: {answer_out}\n^^^^")
                                sys.exit(1)

                        t=math.exp(j/5)
                        if not answer_out:
                            log("NONE: Exist because of answer_out:{answer_out}")
                            sys.exit(1)
                        elif (
                            answer_out == ""
                            or answer_out == ",,,"
                            or len(answer_out) <= 10
                        ):
                            log(f"^^^^\nERROR: answer_out: {answer_out}\n^^^^")
                            log("sleep 60")
                            time.sleep(60)
                        else:
                            log(f"^^^^\nSUCCESSFULLY: answer_out: {answer_out[:90]}...\n^^^^")
                            log(f"wait with exp for {str(t)[:3]}s")
                            time.sleep(t)

                            self.output_texts.append(answer_out)
                            log(
                                "+++++++++++++++++++++++++++++++++++\n",
                                f"{i+1}/{len(output_texts_Chatgptbz)} {task} ✔",
                            )
                            break
                    else:
                        log(f"^^^^\nSTOP: answer_out: {answer_out}\n^^^^")
                        sys.exit(1)
            else:
                log(f"deactivate this part")
                sys.exit(1)
                self.list_list_as_messages = []
                self.get_pages_as_messages_self(
                    self.output_texts,
                    task,
                )
                log(
                    "===========================================\n"
                    f"list_as_messages:{len(self.list_list_as_messages)}"
                    f" item in task {task}",
                )
                self.output_texts = []
                for i, messages in enumerate(self.list_list_as_messages):
                    log(
                        "+++++++++++++++++++++++++++++++++++\n",
                        f"{messages}\n",
                    )
                    self.get_llm(task, messages)
                    log(
                        "+++++++++++++++++++++++++++++++++++\n",
                        f"{i+1}/{len(self.list_list_as_messages)} {task} ✔",
                    )

        return self.output_texts

