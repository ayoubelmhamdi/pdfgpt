#!/usr/bin/env python3
from flask import Flask
from flask import jsonify
from flask import request

from .pptgpt import pdf_to_json

app = Flask(__name__)


@app.route("/pdf2json", methods=["POST"])
def pdf2json():
    # get the PDF file from the request
    pdf_file = request.files.get("pdf")
    if not pdf_file:
        return jsonify({"error": "No PDF file provided"}), 400

    data = pdf_to_json(pdf_file)
    return jsonify(data), 200
