#!/bin/bash
# shellcheck disable=2181

Url="https://chat.aivvm.com/api/chat"

Admin="${1:-}"
if [ -z "$Admin" ];then
  echo "You Not proved any admin Rull"
  exit 1
fi

User="${2:-}"
if [ -z "$User" ];then
  echo "You Not proved any user message"
  exit 1
fi


Json_data=$(cat <<EOF
{
  "model": {
    "id": "gpt-4-32k",
    "name": "GPT-4-32K"
  },
  "messages": [
    {
      "role": "system",
      "content": "${Admin}"
    },
    {
      "role": "user",
      "content": "${User}"
    }
  ],
  "key": "",
  "prompt": "You are ChatGPT, a large language model trained by OpenAI. Follow the user's instructions carefully. Respond using markdown.",
  "temperature": 0.7
}
EOF
)

# ip="218.65.6.150:3128" # proxy abort status 56
# ip="45.173.12.138:1994" # macos,,, slow
ip="201.91.82.155:3128" # work now from github
# from https://premiumproxy.net/https-ssl-proxy-list

# ip="103.18.46.250:443"
# ip="125.25.82.190:8080"
# ip="91.200.163.190:8088"
# ip="178.237.181.218:8080"
# ip="45.11.95.165:5000"
# ip="45.143.222.176:1453"
# ip="78.47.96.120:3128"
# ip="190.237.124.205:999"
# ip="115.132.32.91:8080"
# ip="190.217.23.5:999"

# Send the POST request using curl and save the response to a file

# set -x
trap 'exit 0' INT EXIT
status=28
i=5

working_dir=${0%/*}

while [ $status -eq 28 ];do
  # test without data
  # time curl -vv --connect-timeout 3 -I -X HEAD -H "accept: */*" -H "accept-language: en,fr-FR;q=0.9,fr;q=0.8,es-ES;q=0.7,es;q=0.6,en-US;q=0.5,am;q=0.4,de;q=0.3" -H "origin: https://chat.aivvm.com" -H "referer: https://chat.aivvm.com/" -H "sec-ch-ua: \"Google Chrome\";v=\"117\", \"Not;A=Brand\";v=\"8\", \"Chromium\";v=\"117\"" -H "sec-ch-ua-mobile: ?0" -H "sec-ch-ua-platform: \"macOS\"" -H "sec-fetch-dest: empty" -H "sec-fetch-mode: cors" -H "sec-fetch-site: same-origin" -H "user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36" -x "$ip" "$Url"
  # test with data and proxy ip
  # curl -s --connect-timeout $i -x "$ip" -X POST -H "Content-Type: application/json" -H "accept: */*" -H "accept-language: en,fr-FR;q=0.9,fr;q=0.8,es-ES;q=0.7,es;q=0.6,en-US;q=0.5,am;q=0.4,de;q=0.3" -H "origin: https://chat.aivvm.com" -H "referer: https://chat.aivvm.com/" -H "sec-ch-ua: \"Google Chrome\";v=\"117\", \"Not;A=Brand\";v=\"8\", \"Chromium\";v=\"117\"" -H "sec-ch-ua-mobile: ?0" -H "sec-ch-ua-platform: \"macOS\"" -H "sec-fetch-dest: empty" -H "sec-fetch-mode: cors" -H "sec-fetch-site: same-origin" -H "user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36" -d "$Json_data" "$Url"
  "$working_dir/curl_chrome116" -s --connect-timeout $i -X POST -H "Content-Type: application/json" -H "accept: */*" -H "accept-language: en,fr-FR;q=0.9,fr;q=0.8,es-ES;q=0.7,es;q=0.6,en-US;q=0.5,am;q=0.4,de;q=0.3" -H "origin: https://chat.aivvm.com" -H "referer: https://chat.aivvm.com/" -H "sec-ch-ua: \"Google Chrome\";v=\"117\", \"Not;A=Brand\";v=\"8\", \"Chromium\";v=\"117\"" -H "sec-ch-ua-mobile: ?0" -H "sec-ch-ua-platform: \"macOS\"" -H "sec-fetch-dest: empty" -H "sec-fetch-mode: cors" -H "sec-fetch-site: same-origin" -H "user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36" -d "$Json_data" "$Url"
  status=$?
  if [ $status -ne 28 ];then
    echo >&2
    echo "last timeout is: $i" >&2
    echo "last status of curl is: $status" >&2
  fi

  i=$(( i + 1 ))
  if [ $i -eq 10 ];then
    echo "curl after 10 time status=$status" >&2
    exit 1
  fi
done

exit $status
