#!/usr/bin/env python3

PROMPT = {
    "correct_ocr": {
        "fr": {
            "admin": "Ce texte provient d'un OCR qui a extrait le texte d'une "
            "image. Votre mission est de produire une version plus cohérente "
            "du texte, car l'OCR a généré des erreurs.",
            #
            "prefix": "- Ne parlez pas, juste exécuter simplement ce qui suit, "
            "corrigez simplement les fautes d'orthographe, de grammaire, de "
            "ponctuation et de formatage dans un seul bloc de texte.\n- Si "
            "certaines parties du texte manquent ou ne sont pas claires, "
            "remplissez-les avec des mots appropriés en fonction du contexte "
            "pour devenir cohérent et clair et concis.\n- Supprimez les "
            "segments de texte qui n'ont aucun sens.\n- Utilisez une mise en "
            "forme agréable dans votre réponse pour afficher les phrases "
            "correctes, et utilisez le format Latex pour les formules mathématiques.",
            #
            "max_tokens": 500,
            "model": "gpt-3.5-turbo",
        },
        "en": {
            "admin": "This text comes from an OCR that has extracted the "
            "text from an image. Your mission is to produce a more consistent "
            "version of the text, as the OCR generated errors.",
            #
            "prefix": "- Don't talk, just simply execute the following, simply "
            "correct spelling, grammar, punctuation and formatting errors in a "
            "single block of text.\n- If some parts of the text are missing or "
            "unclear, fill them with appropriate words based on the context to "
            "become coherent and clear and concise.\n- Remove text segments "
            "that make no sense.\n- Use nice formatting in your answer to "
            "display the correct sentences, and use Latex formatting for math "
            "formulas.",
            #
            "max_tokens": 500,
            "model": "gpt-3.5-turbo",
        },
    },
    "paraphrasing": {
        "fr": {
            "admin": "reformuler, structurer et transformer le texte fourni en "
            "utilisant le formatage Markdown",
            #
            "prefix": "Ne parlez pas, juste exécuter simplement ce qui suit, "
            "juste reformuler et structurer et transformer le texte fourni en utilisant "
            "le formatage Markdown, tout en conservant les tableaux originaux "
            ". Suivez ces directives :\n\n- **Élimination des "
            "introductives** : Transformez le texte fourni en supprimant les "
            "phrases d'introduction pour rendant le message plus direct, et "
            "présenter les informations de manière concise.\n- **Évitez la "
            "redondance** : Éliminez les répétitions en reformulant ou en "
            "réorganisant le texte.\n- **Présentation claire** : Expliquez "
            "simplement les termes ou idées complexes. Donnez des exemples "
            "pertinents. Si des termes sont spécifiques à un domaine, "
            "expliquez-les brièvement.\n- **Structure** : Décomposez les idées "
            "en sous-sections pour faciliter la compréhension. Utilisez des mots "
            "de liaison pour assurer une transition fluide entre les "
            "sections.\n- **Langage** : Utilisez un langage simple et approprié. "
            "Évitez le jargon inutile. Assurez-vous que le texte est adapté à un "
            "public instruit, mais non spécialisé.\n\nTexte original :",
            "max_tokens": 2000,
            "model": "gpt-3.5-turbo-16k",
        },
        "en": {
            "admin": "Please simplify this text for the beginner",
            #
            "prefix": "Please simplify this text using Markdown formatting "
            "(like headings, math, bold ...) and using these steps:\n\n"
            "- If there are any hard words or ideas, explain them in a simple "
            "way.\n\n"
            "- Use short and simple sentences.\n"
            "- Use easy words that most people know.\n"
            "- add examples that are easy to understand.\n"
            "- Avoid using words that are specific to a certain field or "
            "topic.\n"
            "- Make complex ideas easier by breaking them into smaller "
            "parts.\n"
            "- Use the subject-verb-object order in your sentences.\n"
            "- Avoid using too many words that describe or modify other "
            "words.\n"
            "- Use words that show how your ideas are related.\n"
            "- Check your work carefully to make sure it is clear and easy to "
            "read.\n",
            #
            "max_tokens": 2000,
            "model": "gpt-3.5-turbo-16k",
        },
    },
    "child": {
        "fr": {
            "admin": "",
            "prefix": "",
            "max_tokens": 2000,
            "model": "gpt-3.5-turbo-16k",
        },
        "en": {
            "admin": "",
            "prefix": "",
            "max_tokens": 2000,
            "model": "gpt-3.5-turbo-16k",
        },
    },
    "ppt": {
        "fr": {
            "admin": ""
            ""
            ""
            "Ce texte provient d'un OCR qui a extrait le texte d'une image. "
            "Votre mission est de produire une version plus cohérente du "
            "texte, car l'OCR a généré des erreurs. Analysez le texte et "
            "identifiez les éléments suivants s'ils sont présents : titres, "
            "sous-titres, paragraphes et images. Utilisez la taille de la "
            "police (font_size) et la direction du texte pour les "
            "reconnaître.\n\n"
            "Ne reformulez pas (paraphrasez) le texte, corrigez simplement "
            "les fautes d'orthographe, de grammaire, de ponctuation et de "
            "mise en forme. Si certaines parties du texte sont manquantes ou "
            "peu claires, complétez-les avec des mots appropriés en fonction "
            "du contexte. "
            "Utilisez le format Markdown dans votre réponse pour afficher "
            "correctement les éléments de texte. "
            ""
            "",
            "prefix": "",
            "max_tokens": 2000,
            "model": "gpt-3.5-turbo-16k-0613",
        },
        "en": {
            "admin": ""
            ""
            ""
            "This text comes from an OCR that has extracted the text from an "
            "image. Your mission is to produce a more consistent version of "
            "the text, as the OCR generated errors. Analyze the text and "
            "identify the following elements if present: titles, subtitles, "
            "paragraphs and images. Use the font size (font_size) and text "
            "direction to recognize them.\n\n"
            "Do not reformulate (paraphrase) the text, just correct the "
            "spelling, grammar, punctuation and formatting errors. If some "
            "parts of the text are missing or unclear, fill them with "
            "appropriate words based on the context.\n\n"
            "Use markdown format in your response to display the text elements "
            "properly."
            ""
            "",
            "prefix": "",
            "max_tokens": 2000,
            "model": "gpt-3.5-turbo-16k-0613",
        },
    },
    "function": {
        "ppt": {
            "fr": {
                "name": "extraire_structure_texte",
                "description": "Analysez ce texte pour extrayez les champs suivants s’ils existent: le titre, le sous-titre, les paragraphes et l’image. Essayez de déterminer ces champs en vous basant sur la taille de la police (font_size) et le contexte du texte. remove HTML tags",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "title": {
                            "type": "string",
                            "description": "le titre principal du texte s'il existent, sans leur numéro de niveau",
                        },
                        "subtitle": {
                            "type": "string",
                            "description": "le sous-titre principal du texte s’ils existent, sans leur numéro de niveau",
                        },
                        "paragraphs": {
                            "type": "string",
                            "description": "les paragraphes du texte s’ils existent",
                        },
                        "image": {
                            "type": "string",
                            "description": "l'image s'ils exsitent comme: 2024_05_23_df24b76b67ff27b86aa9g-2.jpg",
                        },
                    },
                    # "required": ["paragraphes"],
                },
            },
            "en": {},
        },
    },
}
