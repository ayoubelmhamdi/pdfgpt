#!/usr/bin/env python3

PROMPT = {
    "correct_ocr": {
        "fr": {
            "admin": "Ce texte provient d'un OCR qui a extrait le texte d'une "
            "image. Votre mission est de produire une version plus cohérente "
            "du texte, car l'OCR a généré des erreurs.",
            #
            "prefix": "Ne reformulez pas (paraphrasez) le texte, corrigez "
            "simplement les erreurs d’orthographe, de grammaire, de ponctuation "
            "et de formatage. Si certaines parties du texte manquent ou ne sont "
            "pas claires, remplissez-les avec des mots appropriés en fonction "
            "du contexte pour devenir cohérent et clair. Utilisez une mise en "
            "forme agréable dans votre réponse pour afficher les phrases "
            "correctes.",
            #
            "max_tokens": 4000,
            "model": "gpt-3.5-turbo-16k",
        },
        "en": {
            "admin": "This text comes from an OCR that has extracted the "
            "text from an image. Your mission is to produce a more consistent "
            "version of the text, as the OCR generated errors.",
            #
            "prefix": "Do not rephrase (paraphrase) the text, just correct "
            "spelling, grammar, punctuation and formatting errors. If some "
            "parts of the text are missing or unclear, fill them with "
            "appropriate words based on the context to become coherent and "
            "clear. Use nice formatting in your answer to show the correct "
            "sentences.",
            #
            "max_tokens": 4000,
            "model": "gpt-3.5-turbo-16k",
        },
    },
    "paraphrasing": {
        "fr": {
            "admin": "Veuillez simplifier ce texte pour le débutant",
            #
            "prefix": ""
            "Veuillez simplifier ce texte en utilisant le formatage Markdown "
            "(comme les "
            "titres # et ##, les mathématiques $, le gras...) "
            "et en suivant ces étapes :  \n\n"
            "- S'il y a des mots ou des idées difficiles, expliquez-les de manière "
            "simple.\n"
            "- Utilisez des phrases courtes et simples.\n"
            "- Utilisez des mots simples que la plupart des gens connaissent.\n"
            "- Ajoutez des exemples faciles à comprendre.\n"
            "- Évitez d'utiliser des mots spécifiques à un certain domaine ou sujet.\n"
            "- Facilitez les idées complexes en les divisant en parties plus petites.\n"
            "- Utilisez l'ordre sujet-verbe-objet dans vos phrases.\n"
            "- Évitez d'utiliser trop de mots qui décrivent ou modifient d'autres mots.\n"
            "- Utilisez des mots qui montrent comment vos idées sont liées.\n"
            "- Vérifiez soigneusement votre travail pour vous assurer qu'il est clair et "
            "facile à lire. ",
            "max_tokens": 6000,
            "model": "gpt-3.5-turbo-16k",
        },
        "en": {
            "admin": "Please simplify this text for the beginner",
            #
            "prefix": "Please simplify this text using Markdown formatting "
            "(like headings, math, bold ...) and using these steps:\n\n"
            "- If there are any hard words or ideas, explain them in a simple "
            "way.\n\n"
            "- Use short and simple sentences.\n"
            "- Use easy words that most people know.\n"
            "- add examples that are easy to understand.\n"
            "- Avoid using words that are specific to a certain field or "
            "topic.\n"
            "- Make complex ideas easier by breaking them into smaller "
            "parts.\n"
            "- Use the subject-verb-object order in your sentences.\n"
            "- Avoid using too many words that describe or modify other "
            "words.\n"
            "- Use words that show how your ideas are related.\n"
            "- Check your work carefully to make sure it is clear and easy to "
            "read.\n",
            #
            "max_tokens": 6000,
            "model": "gpt-3.5-turbo-16k",
        },
    },
    "child": {
        "fr": {
            "admin": "",
            "prefix": "",
            "max_tokens": 4000,
            "model": "gpt-3.5-turbo-16k",
        },
        "en": {
            "admin": "",
            "prefix": "",
            "max_tokens": 4000,
            "model": "gpt-3.5-turbo-16k",
        },
    },
    "ppt": {
        "fr": {
            "admin": ""
            ""
            ""
            "Ce texte provient d'un OCR qui a extrait le texte d'une image. "
            "Votre mission est de produire une version plus cohérente du "
            "texte, car l'OCR a généré des erreurs. Analysez le texte et "
            "identifiez les éléments suivants s'ils sont présents : titres, "
            "sous-titres, paragraphes et images. Utilisez la taille de la "
            "police (font_size) et la direction du texte pour les "
            "reconnaître.\n\n"
            "Ne reformulez pas (paraphrasez) le texte, corrigez simplement "
            "les fautes d'orthographe, de grammaire, de ponctuation et de "
            "mise en forme. Si certaines parties du texte sont manquantes ou "
            "peu claires, complétez-les avec des mots appropriés en fonction "
            "du contexte. "
            "Utilisez le format Markdown dans votre réponse pour afficher "
            "correctement les éléments de texte. "
            ""
            "",
            "prefix": "",
            "max_tokens": 4000,
            "model": "gpt-3.5-turbo-16k-0613",
        },
        "en": {
            "admin": ""
            ""
            ""
            "This text comes from an OCR that has extracted the text from an "
            "image. Your mission is to produce a more consistent version of "
            "the text, as the OCR generated errors. Analyze the text and "
            "identify the following elements if present: titles, subtitles, "
            "paragraphs and images. Use the font size (font_size) and text "
            "direction to recognize them.\n\n"
            "Do not reformulate (paraphrase) the text, just correct the "
            "spelling, grammar, punctuation and formatting errors. If some "
            "parts of the text are missing or unclear, fill them with "
            "appropriate words based on the context.\n\n"
            "Use markdown format in your response to display the text elements "
            "properly."
            ""
            "",
            "prefix": "",
            "max_tokens": 4000,
            "model": "gpt-3.5-turbo-16k-0613",
        },
    },
    "function": {
        "ppt": {
            "fr": {
                "name": "extraire_structure_texte",
                "description": "Analysez ce texte pour extrayez les champs suivants s’ils existent: le titre, le sous-titre, les paragraphes et l’image. Essayez de déterminer ces champs en vous basant sur la taille de la police (font_size) et le contexte du texte. remove HTML tags",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "title": {
                            "type": "string",
                            "description": "le titre principal du texte s'il existent, sans leur numéro de niveau",
                        },
                        "subtitle": {
                            "type": "string",
                            "description": "le sous-titre principal du texte s’ils existent, sans leur numéro de niveau",
                        },
                        "paragraphs": {
                            "type": "string",
                            "description": "les paragraphes du texte s’ils existent",
                        },
                        "image": {
                            "type": "string",
                            "description": "l'image s'ils exsitent comme: 2024_05_23_df24b76b67ff27b86aa9g-2.jpg",
                        },
                    },
                    # "required": ["paragraphes"],
                },
            },
            "en": {},
        },
    },
}
