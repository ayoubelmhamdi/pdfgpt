#!/usr/bin/env python3

class Variables:
    OCR_FR = """
    Ce texte provient d'un OCR qui a extrait le texte d'une image.
    Votre mission est de produire une version plus cohérente du texte,
    car l'OCR a généré des erreurs.
    
    Ne reformulez pas (paraphrasez) le texte, corrigez simplement les
    erreurs d’orthographe, de grammaire, de ponctuation et de
    formatage. Si certaines parties du texte manquent ou ne sont pas
    claires, remplissez-les avec des mots appropriés en fonction du
    contexte. Utilisez le format markdown dans votre réponse pour
    afficher correctement les éléments de texte. 
    """
    
    OCR_EN = """
    This text comes from an OCR that has extracted the text from an
    image. Your mission is to produce a more consistent version of the
    text, as the OCR generated errors. 
    
    Do not reformulate (paraphrase) the text, just correct the
    spelling, grammar, punctuation, and formatting errors. If some
    parts of the text are missing or unclear, fill them with
    appropriate words based on the context. Use markdown format in
    your response to display the text elements properly like 
    Using # and ## for headings and $ for math.
    """

    OCR_PPT_FR = """
    Ce texte provient d'un OCR qui a extrait le texte d'une image.
    Votre mission est de produire une version plus cohérente du
    texte, car l'OCR a généré des erreurs. Analysez le texte et
    identifiez les éléments suivants s'ils sont présents : titres,
    sous-titres, paragraphes et images. Utilisez la taille de la
    police (font_size) et la direction du texte pour les
    reconnaître.
    
    Ne reformulez pas (paraphrasez) le texte, corrigez simplement
    les fautes d'orthographe, de grammaire, de ponctuation et de
    mise en forme. Si certaines parties du texte sont manquantes ou
    peu claires, complétez-les avec des mots appropriés en fonction
    du contexte.
    
    Utilisez le format Markdown dans votre réponse pour afficher
    correctement les éléments de texte.
    """
    
    OCR_PPT_EN = """
    This text comes from an OCR that has extracted the text from an
    image. Your mission is to produce a more consistent version of
    the text, as the OCR generated errors. Analyze the text and
    identify the following elements if present: titles, subtitles,
    paragraphs and images. Use the font size (font_size) and text
    direction to recognize them.
    
    Do not reformulate (paraphrase) the text, just correct the
    spelling, grammar, punctuation and formatting errors. If some
    parts of the text are missing or unclear, fill them with
    appropriate words based on the context.
    
    Use markdown format in your response to display the text elements properly.
    """
    
    FUNCTION_EXTRAIRE_STRUCTURE_TEXTE_EN = {}

    FUNCTION_EXTRAIRE_STRUCTURE_TEXTE_FR = {
        "name": "extraire_structure_texte",
        "description": "Analysez ce texte pour extrayez les champs suivants s’ils existent: le titre, le sous-titre, les paragraphes et l’image. Essayez de déterminer ces champs en vous basant sur la taille de la police (font_size) et le contexte du texte. remove HTML tags",
        "parameters": {
            "type": "object",
            "properties": {
                "title": {
                    "type": "string",
                    "description": "le titre principal du texte s'il existent, sans leur numéro de niveau",
                },
                "subtitle": {
                    "type": "string",
                    "description": "le sous-titre principal du texte s’ils existent, sans leur numéro de niveau",
                },
                "paragraphs": {
                    "type": "string",
                    "description": "les paragraphes du texte s’ils existent",
                },
                "image": {
                    "type": "string",
                    "description": "l'image s'ils exsitent comme: 2024_05_23_df24b76b67ff27b86aa9g-2.jpg",
                },
            },
            # "required": ["paragraphes"],
        },
    }

    
    PARAPHRASING_EN = """
    Please simplify this text using Markdown formatting (like headings, math,
    bold ...) and using these steps:
    
    - If there are any hard words or ideas, explain them in a simple way.
    - Use short and simple sentences.
    - Use easy words that most people know.
    - add examples that are easy to understand.
    - Avoid using words that are specific to a certain field or topic.
    - Make complex ideas easier by breaking them into smaller parts.
    - Use the subject-verb-object order in your sentences.
    - Avoid using too many words that describe or modify other words.
    - Use words that show how your ideas are related.
    - Check your work carefully to make sure it is clear and easy to read.
    """
    
    PARAPHRASING_FR = """
    Veuillez simplifier ce texte en utilisant le formatage Markdown (comme les
    titres # et ##, les mathématiques $, le gras...) et en suivant ces étapes : 
    - S'il y a des mots ou des idées difficiles, expliquez-les de manière
      simple. 
    - Utilisez des phrases courtes et simples. 
    - Utilisez des mots simples que la plupart des gens connaissent. 
    - Ajoutez des exemples faciles à comprendre. 
    - Évitez d'utiliser des mots spécifiques à un certain domaine ou sujet. 
    - Facilitez les idées complexes en les divisant en parties plus petites. 
    - Utilisez l'ordre sujet-verbe-objet dans vos phrases. 
    - Évitez d'utiliser trop de mots qui décrivent ou modifient d'autres mots. 
    - Utilisez des mots qui montrent comment vos idées sont liées. 
    - Vérifiez soigneusement votre travail pour vous assurer qu'il est clair et
      facile à lire.
    """

    PARAPHRASING_PREFIX_EN = "Please simplify this text"
    PARAPHRASING_PREFIX_FR = "Veuillez simplifier ce texte"
